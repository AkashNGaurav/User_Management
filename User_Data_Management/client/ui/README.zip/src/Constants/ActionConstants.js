export const LOGINUSERDETAILS = "LOGIN_USER_DETAILS";
export const SignUpUserDetails = "SIGNUP_USER_DETAILS";
export const USER_DETAILS = "USER_DETAILS";
export const FILTERS = "FILTERS";
export const SEARCH = "SEARCH";
export const DRILLDOWNGRAPH = "DRILLDOWNGRAPH";